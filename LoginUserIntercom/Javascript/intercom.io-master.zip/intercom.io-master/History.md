
1.0.5 / 2014-10-24
==================

  * Update `request` dependency

1.0.4 / 2014-10-24
==================

  * Update `qs` dependency

1.0.3 / 2014-09-20
==================

  * Added support for Conversations

1.0.2 / 2014-09-20
==================

  * User POST for updateUser

1.0.1 / 2014-09-12
==================

  * Support for intercom.io errors

1.0.0 / 2014-09-11
==================

  * Major overhaul to the API

0.0.8 / 2014-05-04
==================

  * Update support for promises

0.0.7 / 2014-05-04
==================

  * Added support for promises

0.0.6 / 2014-04-27
==================

  * Added createEvent

0.0.5 / 2014-02-18
==================

  * Fixed delete user

0.0.4 / 2013-10-31
==================

  * Fixed JSON Body Errors

0.0.3 / 2013-10-05
==================

  * Added basic integration tests

0.0.2 / 2013-10-05
==================

  * Added docs
  * Made it work with just passing in options

0.0.1 / 2013-07-03
==================

  * Initial release
