// Imports [intercom.io.js](lib/intercom.io.js.html)
module.exports = require('./lib/intercom.io');
